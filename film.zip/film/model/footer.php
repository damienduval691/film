<footer class="siteFooter">
    <div>
        DUVAL Damien, DACHEUX Corentin, DESJARDIN Paul
    </div>
</footer>