<header class="siteHeader">
  <h1 class="mainTitle"><a href="index">Accueil du site</a></h1>
  <div class="navigationMenu">
    <a class="buttonMenu" href="pages/add"> <img src="img/plus.png" style="width: 20px; height: 20px;"> un film</a>
    <!--<a class="buttonMenu" href="pages/delete"><img src="img/bouton-supprimer.png" style="width: 20px; height: 20px;">Supprimer un film</a> => Boutton directement ajouter dans le tableau-->
    <!--<a class="buttonMenu" href="pages/udpate"><img src="img/modifier-le-texte.png" style="width: 20px; height: 20px;">Mettre à jour un film</a> => Button directement ajouter dan le tableau-->
    <a class="buttonMenu" href="pages/research"><img src="img/search-engine-optimization.png" style="width: 20px; height: 20px;">Rechercher un film</a>
  </div>
</header>